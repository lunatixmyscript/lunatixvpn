from cybervpn import *
from telethon import events, Button
import requests

#url = "https://raw.githubusercontent.com/messiey/rocky/master/statushariini"

response = requests.get(url)


if response.status_code == 200:
    print(response.text)
else:
    print("Gagal mendapatkan konten dari URL")

@bot.on(events.NewMessage(pattern=r"(?:.menu|/start|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def start_menu(event):
    user_id = str(event.sender_id)

    if check_user_registration(user_id):
        try:
            saldo_aji, level = get_saldo_and_level_from_db(user_id)

            if level == "user":
                member_inline = [
                    [Button.inline("SSH OPENVPN", "ssh")],
                    [Button.inline("VMESS LIBEV", "vmess-member"),
                     Button.inline("VLESS LIBEV", "vless-member")],
                    [Button.inline("TRJAN LIBEV", "trojan-member"),
                     Button.inline("SHADOWSOCKS", "shadowsocks-member")],
                    [Button.inline("NOOBZ VPNS", "noobzvpn-member")],
                    [Button.url("WA CHANNEL", "https://whatsapp.com/channel/0029Vab9k1u0VycAADOxm342"),
                     Button.inline("TOP UP", f"topup")]
                ]

                member_msg = f"""
**━━━━━━━━━━━━━━━━**
    ` 👑LUNATIX TUNNEL👑`
**━━━━━━━━━━━━━━━━**
**━━━━━━━━━━━━━━━━**
**» ☠️Version:** `4.4.4.4 LT.`
**» ☠️Bot by @LunaticTunnel **
**» ☠️Your ID ** `{user_id}`
**━━━━━━━━━━━━━━━━**
**» ☠️SALDO LU: ** `RP.{saldo_aji}`
**━━━━━━━━━━━━━━━━**
"""
                x = await event.edit(member_msg, buttons=member_inline)
                if not x:
                    await event.reply(member_msg, buttons=member_inline)


            elif level == "admin":
                admin_inline = [
                    [Button.inline("SSH OPENVPN", "ssh")],
                    [Button.inline("VMESS LIBEV", "vmess"),
                     Button.inline("VLESS LIBEV", "vless")],
                    [Button.inline("TRJAN LIBEV", "trojan"),
                     Button.inline("SHADOWSOCKS", "shadowsocks")],
                    [Button.inline("NOOBZ VPNS", "noobzvpns"),
                     Button.inline("ADD MEMBER", "registrasi-member"),
                     Button.inline("DEL MEMBER", "delete-member")],
                     [Button.inline("MEMBER LIST", "show-user")],
                    [Button.inline("☠️ADD MEMBER SALDO☠️", "addsaldo")],
                    [Button.inline("🇲🇨VPS INFO🇲🇨", "info"),
                     Button.inline("🔆SET MANAGER🔆", "setting")],
                    [Button.url("WA CHANNEL", "https://whatsapp.com/channel/0029Vab9k1u0VycAADOxm342"),
                     Button.url("ORDER SC", "https://t.me/LunaticTunnel")]
                ]

                admin_msg = f"""
**━━━━━━━━━━━━━━━━**
     `👑LUNATIX TUNNEL👑`
**━━━━━━━━━━━━━━━━**
**» ☠️Version:** `4.4.4.4 LT.`
**» ☠️Bot by @LunaticTunnel**
**» ☠️Your ID ** `{user_id}`
**» ☠️Total in db:** `{get_user_count()}`
**━━━━━━━━━━━━━━━━**
"""
                x = await event.edit(admin_msg, buttons=admin_inline)
                if not x:
                    await event.reply(admin_msg, buttons=admin_inline)

        except Exception as e:
            print(f"Error: {e}")

    else:
        await event.reply(
            f'```Anda belum terdaftar, silahkan registrasi```',
            buttons=[[(Button.inline("Registrasi", "registrasi"))]]
        )

